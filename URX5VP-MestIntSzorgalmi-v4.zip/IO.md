# Input
x x x x 3 x 8 x x 6 14 x 5 . . . 12 -7 . . . . 2 . . 4 . . . . . . . . 1

# Expected Output
A maximálisan elérhető nyereség: 3 (Az input példánál). Futási idő: 1.233435324 sec

# Input
3 3 2 1 3 12 8 2 4 6 14 1 5 . . . 12 -7 . . . . 2 . . 4 . . . . . . . . 1 . . . . .

# Expected Output
A teljes fa kiírva szintek szerint:
3
  3
    3
    12
      12
      -7
    8
  2
    2
      2
    4
      4
    6
  1
    14
    1
      1
    5

A maximálisan elérhető nyereség: 3
Futási idő: 0.000000000000000000 sec

# Input
3 5 6 x x 1 4

# Expected Output
A teljes fa kiírva szintek szerint:
3
  5
    1
    4
  6

A maximálisan elérhető nyereség: 6
Futási idő: 0.000000000000000000 sec

# Input
1 2 3 4 5 x x x x 6 7

# Expected Output
A teljes fa kiírva szintek szerint:
1
  2
    5
  3
    6
  4
    7

A maximálisan elérhető nyereség: 7
Futási idő: 0.000000000000000000 sec

# Input
10 20 x 30 40 50 x x x x 60 70 80

# Expected Output
A teljes fa kiírva szintek szerint:
10
  20
    40
    50
  30
    60
    70
    80

A maximálisan elérhető nyereség: 60
Futási idő: 0.000000000000000000 sec